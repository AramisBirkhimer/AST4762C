"""
Created on Fri Aug 29 15:47:40 2025

assignment: HW2

@author: abirk

"""

import numpy as np
import math
import matplotlib.pyplot as plt


# Problem 2

# a1: creat array of integers x from 0-1000
x = np.arange(0,1001)

# a2: print data type, min, max

print(type(x))
print(min(x))
print(max(x))

# b: rescale values between 0 and 2pi

x = 0 + (x - 0) * ((2 * math.pi) - 0) / (1000 - 0)

# b2: print min and max of x

print(min(x))
print(max(x))

# C: make new array y = sin(x)

y = np.sin(x)

# D: print the 234th element of the array
print(y[233])

# problem 3

# plot x vs y and make it publication ready
plt.plot(x,y, label = "sin(x)")
plt.title("Plot of x vs sin(x)")
plt.xlabel("X values")
plt.ylabel("Sin(X)")
plt.legend()
plt.grid(True)

# save to .png file
plt.savefig("plot_3b_abirk.png")
plt.show()

#Problem 4

# a1 make array with 101 values between -1 to 1

x = np.linspace(-1, 1, 101)

# a2: mask the array so that x>.5 = .5 and x<-.5 = -.5

y = np.clip(x, -0.5, .5)
print(y)
print(x)

# b1: plot clipped and original arrays 
plt.plot(y, label = "Masked array")
plt.plot(x, label = "Original array")
plt.title("Array vs masked array")
plt.xlabel("X Values")
plt.ylabel("Y Values")
plt.legend()

# b2: save plot as pdf
plt.savefig("plot_4b2_abirk.pdf")
plt.show()


#Problem 5: find two websites outside ucf that offer astro python packages

'''
(https://www.astropy.org/).

Astropy is like having a complete astronomy toolkit that handles all the annoying stuff like unit conversions and coordinate transformations automatically. You can use it for working with FITS files from telescopes and dealing with different time systems - making data analysis so much smoother. 

(https://pypi.org/project/pywwt/). 

You can create interactive, web-based planetarium shows right in your Jupyter notebooks, which is perfect when you want to share your findings with others. You can load your own data, explore different regions of the sky, and create professional-looking visualizations. it is super helpful for both your research and when you're putting together presentations.

'''
