#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Below is the result of me asking copilot to make a clock 


# In[3]:


import tkinter as tk
import math

class CountdownClock:
    def __init__(self, root, duration_seconds):
        self.root = root
        self.duration = duration_seconds
        self.elapsed = 0

        self.canvas_size = 300
        self.center = self.canvas_size // 2
        self.radius = self.center - 20

        self.canvas = tk.Canvas(root, width=self.canvas_size, height=self.canvas_size, bg='white')
        self.canvas.pack()

        self.label = tk.Label(root, text="", font=("Helvetica", 14))
        self.label.pack()

        self.update_clock()

    def draw_clock_face(self):
        # Draw outer circle
        self.canvas.create_oval(
            self.center - self.radius, self.center - self.radius,
            self.center + self.radius, self.center + self.radius,
            outline='black', width=2
        )

        # Draw hour marks
        for i in range(12):
            angle = math.radians(i * 30 - 90)
            x_outer = self.center + self.radius * math.cos(angle)
            y_outer = self.center + self.radius * math.sin(angle)
            x_inner = self.center + (self.radius - 10) * math.cos(angle)
            y_inner = self.center + (self.radius - 10) * math.sin(angle)
            self.canvas.create_line(x_inner, y_inner, x_outer, y_outer, fill='black', width=2)

    def draw_second_hand(self):
        angle = (self.elapsed % 60) * 6  # 360 degrees / 60 seconds
        rad = math.radians(angle - 90)
        x = self.center + self.radius * 0.85 * math.cos(rad)
        y = self.center + self.radius * 0.85 * math.sin(rad)
        self.canvas.create_line(self.center, self.center, x, y, fill='red', width=2)

    def update_clock(self):
        self.canvas.delete("all")
        self.draw_clock_face()
        self.draw_second_hand()

        remaining = max(0, self.duration - self.elapsed)
        self.label.config(text=f"Elapsed: {self.elapsed}s   Remaining: {remaining}s")

        if self.elapsed < self.duration:
            self.elapsed += 1
            self.root.after(1000, self.update_clock)
        else:
            self.label.config(text="Time's up!")

def main():
    minutes = float(input("Enter countdown time in minutes: "))
    duration_seconds = int(minutes * 60)
    root = tk.Tk()
    root.title("White Clock Timer")
    CountdownClock(root, duration_seconds)
    root.mainloop()

if __name__ == "__main__":
    main()


# In[ ]:


#I ran the code and the output is almost right but the hand moves every second


# In[ ]:


#Piston test: my response (10 minutes)


# In[ ]:


import math

def piston(v, p0, v0, t0, gamma):
    v = input("Please enter the final volume of the container: ")
    p0 = input("\nPlease enter initial pressure: ")
    v0 = input("\nPlease enter initial volume: ")
    t0 = input("\nPlease enter initial temperature: ")
    gamma = input("\nPlease enter adiabatic constant: ")
    


# In[ ]:


#Piston Test: AI response


# In[1]:


import numpy as np

def piston(V, P0, V0, T0, gamma):
    # Calculate pressure using adiabatic law
    P = P0 * (V0 / V) ** gamma
    # Calculate temperature using ideal gas law
    T = T0 * (P / P0) * (V / V0)
    # Stack results into (N, 3) array
    result = np.column_stack((P, V, T))
    return result

# Generate volume array
V = np.linspace(1.0, 0.1, 40)
# Initial conditions
P0 = 1.0  # atm
V0 = 1.0  # liter
T0 = 300  # Kelvin
gamma = 1.4

# Call the function
data = piston(V, P0, V0, T0, gamma)
print(data)


import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Extract columns
P, V_vals, T = data[:,0], data[:,1], data[:,2]

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Plot surface
ax.plot_trisurf(V_vals, P, T, cmap='viridis', edgecolor='none')

# Labels and title
ax.set_xlabel('Volume (L)')
ax.set_ylabel('Pressure (atm)')
ax.set_zlabel('Temperature (K)')
ax.set_title('Adiabatic Compression of Dry Air in a Piston')

# Save plot
plt.savefig('piston_surface_plot.png')
plt.show()


# In[ ]:


#The code written by the AI did a great job of calculating the values and plotting them
#in a timely manner, but I do not have the time to check it's accuracy right now. 

