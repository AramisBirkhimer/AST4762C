{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "037091e4-2faa-41a5-aa39-e166a887f402",
   "metadata": {},
   "outputs": [],
   "source": [
    "#Below is the result of me asking copilot to make a clock "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "5a51acf5-11e1-49e8-b410-604f1231d9cb",
   "metadata": {},
   "outputs": [
    {
     "name": "stdin",
     "output_type": "stream",
     "text": [
      "Enter countdown time in minutes:  8\n"
     ]
    }
   ],
   "source": [
    "import tkinter as tk\n",
    "import math\n",
    "\n",
    "class CountdownClock:\n",
    "    def __init__(self, root, duration_seconds):\n",
    "        self.root = root\n",
    "        self.duration = duration_seconds\n",
    "        self.elapsed = 0\n",
    "\n",
    "        self.canvas_size = 300\n",
    "        self.center = self.canvas_size // 2\n",
    "        self.radius = self.center - 20\n",
    "\n",
    "        self.canvas = tk.Canvas(root, width=self.canvas_size, height=self.canvas_size, bg='white')\n",
    "        self.canvas.pack()\n",
    "\n",
    "        self.label = tk.Label(root, text=\"\", font=(\"Helvetica\", 14))\n",
    "        self.label.pack()\n",
    "\n",
    "        self.update_clock()\n",
    "\n",
    "    def draw_clock_face(self):\n",
    "        # Draw outer circle\n",
    "        self.canvas.create_oval(\n",
    "            self.center - self.radius, self.center - self.radius,\n",
    "            self.center + self.radius, self.center + self.radius,\n",
    "            outline='black', width=2\n",
    "        )\n",
    "\n",
    "        # Draw hour marks\n",
    "        for i in range(12):\n",
    "            angle = math.radians(i * 30 - 90)\n",
    "            x_outer = self.center + self.radius * math.cos(angle)\n",
    "            y_outer = self.center + self.radius * math.sin(angle)\n",
    "            x_inner = self.center + (self.radius - 10) * math.cos(angle)\n",
    "            y_inner = self.center + (self.radius - 10) * math.sin(angle)\n",
    "            self.canvas.create_line(x_inner, y_inner, x_outer, y_outer, fill='black', width=2)\n",
    "\n",
    "    def draw_second_hand(self):\n",
    "        angle = (self.elapsed % 60) * 6  # 360 degrees / 60 seconds\n",
    "        rad = math.radians(angle - 90)\n",
    "        x = self.center + self.radius * 0.85 * math.cos(rad)\n",
    "        y = self.center + self.radius * 0.85 * math.sin(rad)\n",
    "        self.canvas.create_line(self.center, self.center, x, y, fill='red', width=2)\n",
    "\n",
    "    def update_clock(self):\n",
    "        self.canvas.delete(\"all\")\n",
    "        self.draw_clock_face()\n",
    "        self.draw_second_hand()\n",
    "\n",
    "        remaining = max(0, self.duration - self.elapsed)\n",
    "        self.label.config(text=f\"Elapsed: {self.elapsed}s   Remaining: {remaining}s\")\n",
    "\n",
    "        if self.elapsed < self.duration:\n",
    "            self.elapsed += 1\n",
    "            self.root.after(1000, self.update_clock)\n",
    "        else:\n",
    "            self.label.config(text=\"Time's up!\")\n",
    "\n",
    "def main():\n",
    "    minutes = float(input(\"Enter countdown time in minutes: \"))\n",
    "    duration_seconds = int(minutes * 60)\n",
    "    root = tk.Tk()\n",
    "    root.title(\"White Clock Timer\")\n",
    "    CountdownClock(root, duration_seconds)\n",
    "    root.mainloop()\n",
    "\n",
    "if __name__ == \"__main__\":\n",
    "    main()\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "1a442f59-73bf-4843-a7bc-8f259ce62268",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "8678fcc3-1e82-49e3-ab77-1cd125dca37c",
   "metadata": {},
   "outputs": [],
   "source": [
    "#I ran the code and nothing showed up, so I am going to assume that the program is not operational or I just don't understand\n",
    "#how to use jupyter"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.4"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
